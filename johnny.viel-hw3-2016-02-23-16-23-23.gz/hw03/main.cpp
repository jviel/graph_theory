// Counting and Probability
// CS 251 - Winter 2016
// Written by Johnny Viel 2.18.16
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_permutation.h>
using namespace std;

typedef gsl_matrix matrix;

void MatrixGet( matrix & mat, const char * nm )
{
    int width, dim=1, numElems=0;
    double tempArr[200];
    string input;
    istringstream inbuf;

    cout << "Enter Matrix " << nm << " (enter empty line to finish):" << endl;    
    getline( cin, input );

    // parse first row to determine width of matrix
    inbuf.str( input );
    while( inbuf.peek() != EOF )
        inbuf >> tempArr[numElems++];
    width = numElems;

    // parse rest of matrix
    cin.clear();
    getline( cin, input );
    while( input.length() > 0 ){
        inbuf.clear();
        inbuf.str( input );
        while( inbuf.peek() != EOF )
            inbuf >> tempArr[numElems++];
        cin.clear();
        getline( cin, input );
        dim++;
    }
    
    mat = *gsl_matrix_alloc( dim, width );
    double* cur = tempArr;
    for( int i=0; i<dim; i++ ){
        for( int j=0; j<width; j++ )
            gsl_matrix_set( &mat, i, j, *cur++);
    }
}

void VectorGet( matrix & v, const char * nm )
{
    int numElems=0;
    double tempArr[20];
    string input;
    istringstream inbuf;

    cout << "Enter Vector " << nm << ":" << endl;    
    getline( cin, input );
    inbuf.str( input );

    while( inbuf.peek() != EOF && numElems <= 20 )
        inbuf >> tempArr[numElems++];

    v = *gsl_matrix_alloc( numElems, 1 );
    for( int i=0; i<numElems; i++ )
        gsl_matrix_set( &v, i, 0, tempArr[i] );
}

void MatrixPrint( const matrix & mat )
{
    int width = mat.size2;
    int dim   = mat.size1;
    cout << " is a " << dim << " x " << width << " matrix" << endl << endl << fixed << setprecision(2);
    for( int i=0; i<dim; i++ ){
        cout << "   |";
        for( int j=0; j<width; j++ )
            cout << setw(6) << gsl_matrix_get( &mat, i, j );
        cout << " |";
        cout << endl;
    }
}

void MatrixMul( const matrix &A, const matrix &B )
{
    if( A.size2 == B.size1 ){ 
        matrix prod = *gsl_matrix_alloc( A.size1, B.size2 ); 
        gsl_blas_dgemm( CblasNoTrans, CblasNoTrans, 1.0, &A, &B, 0.0, &prod );
        MatrixPrint( prod );
    }else
        cout << "does not compute: incorrect dimensions" << endl;
}

double _det( matrix &mat )
{
    matrix matCopy = *gsl_matrix_alloc( mat.size1, mat.size2 );
    gsl_matrix_memcpy( &matCopy, &mat );
    int signum;
    gsl_permutation *p = gsl_permutation_alloc( mat.size1 );
    gsl_linalg_LU_decomp( &matCopy, p, &signum );
    gsl_permutation_free(p);
    return gsl_linalg_LU_det( &matCopy, signum );
}

void MatrixInv( matrix &mat )
{
    if( mat.size1 != mat.size2 )
    { cout << "does not compute: matrix is not square" << endl; return; }
    else if( _det(mat) == 0 )
    { cout << "does not compute: determinant is zero" << endl; return; }

    matrix matCopy = *gsl_matrix_alloc( mat.size1, mat.size2 );
    gsl_matrix_memcpy( &matCopy, &mat ); // copy matrix otherwise mat will be changed
    matrix matInv = *gsl_matrix_alloc( mat.size1, mat.size2 );
    gsl_permutation *p = gsl_permutation_alloc( mat.size1 );
    int signum;
    gsl_linalg_LU_decomp( &matCopy, p, &signum ); 
    gsl_linalg_LU_invert( &matCopy, p, &matInv );
    MatrixPrint( matInv );
    gsl_permutation_free( p );
    p = nullptr;
}

void MatrixOuterProd( matrix &A, matrix &B )
{
    int oprow, opcol;
    int rankA = A.size1;
    int dimA  = A.size2;
    int rankB = B.size1;
    int dimB  = B.size2;
    matrix op = *gsl_matrix_alloc( A.size1*B.size1, A.size2*B.size2 );
    matrix Bcopy = *gsl_matrix_alloc( B.size1, B.size2 );
    for( int row=0; row<rankA; row++ ){
        for( int col=0; col<dimA; col++ ){
            gsl_matrix_memcpy( &Bcopy, &B ); // reset Bcopy
            gsl_matrix_scale( &Bcopy, gsl_matrix_get( &A, row, col ));// multiply a_i*B (scalar)
            for( int i=0; i<rankB; i++ ){// move to correct quadrant of tensor
                for( int j=0; j<dimB; j++ ){
                    oprow = i+(row*rankB);
                    opcol = j+(col*dimB);
                    gsl_matrix_set( &op, oprow, opcol, gsl_matrix_get( &Bcopy, i, j ));
                }
            }
        }
    }
    MatrixPrint( op );
}

void MatrixTrace( matrix & mat )
{
    if( mat.size1 != mat.size2 )
    { cout << "does not compute: matrix is not square" << endl; return; }
    double trace = 0;
    for( int i=0; i<mat.size1; i++ )
        trace += gsl_matrix_get( &mat, i, i );
    cout << "is " << trace << endl;
}

void MatrixDet( matrix & mat )
{
    if( mat.size1 != mat.size2 )
    { cout << "does not compute: matrix is not square" << endl; return; }
    double det = _det(mat);
    cout << "is " << det << endl;
}

void MatrixEigen( matrix & mat )
{
    int sz = mat.size1;
    if( sz != mat.size2 ){
        cout << " does not compute: matrix is not square" << endl;
        return;
    }
    gsl_eigen_nonsymm_workspace *ws = gsl_eigen_nonsymm_alloc( sz );
    gsl_matrix_view mv = gsl_matrix_view_array( mat.data, sz, sz );
    gsl_vector_complex *eval = gsl_vector_complex_alloc( sz );
    gsl_eigen_nonsymm( &mv.matrix, eval, ws );
    gsl_complex eval_i;
    cout << "are" << endl << endl << setprecision(10);
    for( int i=0; i<sz; i++ ){
        eval_i = gsl_vector_complex_get( eval, i );
        cout << "   " << (i+1) << ": " << GSL_REAL(eval_i) << "  +  " << GSL_IMAG(eval_i) << " i" << endl;
    }
    gsl_vector_complex_free( eval );
    gsl_eigen_nonsymm_free( ws );
}

int main()
{
    matrix matA, matB, matB_T;
    matrix vectX, vectX_T;
    MatrixGet( matA,  "A" );
    MatrixGet( matB,  "B" );
    VectorGet( vectX, "X" );

    cout << endl;
    cout << "A is a " << matA.size1  << " x " << matA.size2  << " matrix" << endl;
    cout << "B is a " << matB.size1  << " x " << matB.size2  << " matrix" << endl;
    cout << "X is a " << vectX.size1 << " x " << vectX.size2 << " matrix" << endl;
    cout << "Transpose(B) is a " << matB.size2 << " x " << matB.size1 << " matrix" << endl << endl;
    vectX_T = *gsl_matrix_alloc( vectX.size2, vectX.size1 );
    gsl_matrix_transpose_memcpy( &vectX_T, &vectX );
    cout << "xA "; MatrixMul( vectX_T, matA );
    cout << endl;
    cout << "Ax "; MatrixMul( matA, vectX );
    cout << endl;
    cout << "AB "; MatrixMul( matA,  matB );
    cout << endl;
    cout << "A^-1 "; MatrixInv( matA );
    cout << endl;
    cout << "A (x) B (outer prod)"; MatrixOuterProd( matA, matB );
    cout << endl;
    matB_T = *gsl_matrix_alloc( matB.size2, matB.size1 );
    gsl_matrix_transpose_memcpy( &matB_T, &matB );
    cout << "A (x) B^T (outer prod)"; MatrixOuterProd( matA, matB_T );
    cout << endl;
    cout << "trace(A) "; MatrixTrace( matA );
    cout << "det(A) "; MatrixDet( matA );
    cout << "eigenvalues(A) "; MatrixEigen( matA );
    cout << endl;
    return 0;
}
